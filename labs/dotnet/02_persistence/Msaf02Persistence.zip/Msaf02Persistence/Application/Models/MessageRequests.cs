﻿namespace Msaf02Persistence.Application.Models;

public class MessageRequest
{
    public string Content { get; set; } = string.Empty;
}
